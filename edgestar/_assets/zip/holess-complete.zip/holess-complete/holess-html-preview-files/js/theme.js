/*
  Template Name: Holess
  Version: 1.0
  Author: Allies Interactive
  Website: http://www.diziana.com/
  Corporate Website : http://www.diziana.com
  Contact: support@diziana.com
  Follow: https://www.twitter.com/dizianaEngage
  Like: https://www.facebook.com/diziana.engage
  Purchase: Diziana.com
  License: You must have a valid license purchased only from
  diziana.com in order to legally use the theme for your project.
  Copyright: © 2015 Allies Interactive Services Pvt. Ltd. All Rights Reserved
*/
$(function(){ 
	$(".dropdown-menu li a").click(function(){
	  $(this).parents(".btn-group").find('.selector').text($(this).text());
	  $(this).parents(".btn-group").find('.selector').val($(this).text());
	});
	
});

    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
     (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
     m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-52832587-2', 'auto');
    ga('send', 'pageview');